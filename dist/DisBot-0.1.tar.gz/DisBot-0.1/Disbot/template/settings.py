from pathlib import Path
import os

BASE_DIR = Path(__file__).resolve().parent


#! Add any newly created COGS here

COGS=[
    "Cogs.Base",
    "Cogs.General",
    "Cogs.Errors",
]